#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "cpuinfo.h"

#define IS_PREFIXED_BY(line, prefix) \
    (strncmp(line, prefix, strlen(prefix)) == 0)

int isPrefixedBy(char *line, char *prefix)
{
    int i;
    for(i = (strlen(line) - 1); (i > -1) && (line[i] == ' ' || line[i] == 9); i--)
    {}
    return (strncmp(line, prefix, i + 1) == 0);
}

static void rightTrim(char *line)
{
    int32_t i;
    
    /* Last character is always NULL */
    for(i = strlen(line); i >= 0 && line[i] < (' ' + 1); i--) {}
    line[i + 1] = 0;
}


int readCPUInfo(FILE*      cpuinfoFile,
               int        cpu, 
               cpuinfo_t* cpuinfo)
{
    int     bytesRead;
    static char* line = NULL;
    size_t linesize;
    
    cpuinfo->physical_id = 0xFF;
    cpuinfo->core_id = 0xFF;
    
    bytesRead = getline(&line,  &linesize, cpuinfoFile);

    /* Read cpu data */
    while(bytesRead > 1)
    {
        char*  value = strchr(line, ':');
        if (value != NULL) 
        {
            int i;
            *value = '\0';
            value++;
            while (isblank(*value)) value++;
            rightTrim(value);

            if (isPrefixedBy(line, "vendor_id")) 
            {
                if (IS_PREFIXED_BY(value, "GenuineIntel")) 
                {
                    cpuinfo->vendor = VENDOR_INTEL;
                } 
                else if (IS_PREFIXED_BY(value, "AuthenticAMD")) 
                {
                    cpuinfo->vendor = VENDOR_AMD;
                } 
                else if (IS_PREFIXED_BY(value, "CyrixInstead")) 
                {
                    cpuinfo->vendor = VENDOR_CYRIX;
                } 
                else if (IS_PREFIXED_BY(value, "CentaurHauls")) 
                {
                    cpuinfo->vendor = VENDOR_VIA;
                } 
                else if (IS_PREFIXED_BY(value, "UMC UMC UMC ")) 
                {
                    cpuinfo->vendor = VENDOR_UMC;
                } 
                else if (IS_PREFIXED_BY(value, "NexGenDriven")) 
                {
                    cpuinfo->vendor = VENDOR_NEXGEN;
                } 
                else if (IS_PREFIXED_BY(value, "RiseRiseRise")) 
                {
                    cpuinfo->vendor = VENDOR_RISE;
                } 
                else if (IS_PREFIXED_BY(value, "GenuineTMx86")) 
                {
                    cpuinfo->vendor = VENDOR_TRANSMETA;
                } 
                else 
                {
                    int  len = strlen(value);
                    if (value[len] == '\n') 
                    {
                        value[len] = '\0';
                    }
                    fprintf(stderr, "Warning: unrecognized cpuinfo vendor_id: %s\n", value);
                }
            } 
            else if (isPrefixedBy(line, "cpu family")) 
            {
                cpuinfo->family = strtoul(value, NULL, 10);
            } 
            else if (isPrefixedBy(line, "model")) 
            {
                printf("MODEL: %s\n", value);
                cpuinfo->model = strtoul(value, NULL, 10);
            } 
            else if (isPrefixedBy(line, "stepping")) 
            {
                strncpy(cpuinfo->stepping, value, STEPPING_LEN);
                cpuinfo->stepping[STEPPING_LEN] = 0;
            } 
            else if (isPrefixedBy(line, "physical id")) 
            {
                printf("Physical ID: %s\n", value);
                cpuinfo->physical_id = strtoul(value, NULL, 10);
            } 
            else if (isPrefixedBy(line, "core id")) 
            {
                printf("Core ID: %s\n", value);
                cpuinfo->core_id = strtoul(value, NULL, 10);
            } 
            else if (isPrefixedBy(line, "processor")) 
            {
                int processor = strtoul(value, NULL, 10);
                if (processor == cpu + 1) break;
                if (processor > cpu + 1) 
                {
                    fprintf(stderr, "Warning: unable to determine cpuinfo"
                       " for processor %d\n", cpu);
                }
            }
        }
        bytesRead = getline(&line,  &linesize, cpuinfoFile);
    }
    
    if (bytesRead == -1) return -1;
    else return 0;
}


