#include <inttypes.h>

#define STEPPING_LEN 32
#define CPU_INFO_FILE "/proc/cpuinfo"


typedef enum {
   VENDOR_UNKNOWN,
   VENDOR_INTEL,
   VENDOR_AMD,
   VENDOR_CYRIX,
   VENDOR_VIA,
   VENDOR_TRANSMETA,
   VENDOR_UMC,
   VENDOR_NEXGEN,
   VENDOR_RISE
} vendor_t;

typedef struct {
   vendor_t  vendor;
   uint32_t  family;
   uint16_t  model;
   char stepping[STEPPING_LEN + 1];
   uint16_t physical_id;
   uint16_t core_id;
} cpuinfo_t;

int readCPUInfo(FILE*      cpuinfoFile,
               int        cpu, 
               cpuinfo_t* cpuinfo);

