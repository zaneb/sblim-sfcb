
/*
 * Author: Rodolfo Kohn
*/



#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>
#include <libgen.h>

#include "cpuinfo.h"
#include "intelmsr.h"


#include "cmpidt.h"
#include "cmpift.h"
//#include "cmpiftx.h"
#include "cmpimacs.h"
//#include "cmpimacsx.h"


static const CMPIBroker *_broker;
static CMPIStatus invClassSt = { CMPI_RC_ERR_INVALID_CLASS, NULL };
static CMPIStatus notSuppSt = { CMPI_RC_ERR_NOT_SUPPORTED, NULL };
static CMPIStatus okSt = { CMPI_RC_OK, NULL };


#define HOST_NAME_LEN 256
#define DEVICE_ID_LEN 64
#define SYSTEM_NAME_LEN 256
#define SYSTEM_NAME "localhost"

#define ALL_PROCESSORS_CORES 0xFF

static char *getSystemName()
{
    static char hostName[HOST_NAME_LEN + 1];
    int8_t res;
    
    res = gethostname(hostName, HOST_NAME_LEN);
    if (res == -1)
    {
        printf("Error obtaining hostname: %d\n", errno);
        return NULL;
    }
    else
    {
        return hostName;
    }
}





static CMPIInstance *createInstance(uint16_t procFamily, cpuinfo_t *cpuinfo, int cpu)
{
    CMPIUint16 processorFamily = procFamily;
    CMPIUint16 value;
    CMPIInstance   *processorInstance = NULL;
    CMPIStatus     status = {CMPI_RC_OK, NULL};
    CMPIObjectPath *op = NULL;
    char deviceID[DEVICE_ID_LEN + 1];
    char systemName[SYSTEM_NAME_LEN + 1];
    char *systemNamePtr;
    MSRState_t prefetchState;

    op = CMNewObjectPath(_broker, "root/cimv2", "INTEL_Processor", &status);
    if (status.rc != CMPI_RC_OK) printf("ERROR-1\n");
    processorInstance = CMNewInstance(_broker, op, &status);
    if (status.rc != CMPI_RC_OK) printf("ERROR-2\n");
                    
    CMSetProperty(processorInstance, "Family", &processorFamily, CMPI_uint16);
    value = cpuinfo->vendor;
    CMSetProperty(processorInstance, "Vendor", &value, CMPI_uint16);
    value = cpuinfo->model;
    CMSetProperty(processorInstance, "Model", &value, CMPI_uint16);
    CMSetProperty(processorInstance, "Stepping", cpuinfo->stepping, CMPI_chars);
    
    value = cpuinfo->physical_id;
    CMSetProperty(processorInstance, "PhysicalID", &value, CMPI_uint16);
    value = cpuinfo->core_id;
    CMSetProperty(processorInstance, "CoreID", &value, CMPI_uint16);

    CMSetProperty(processorInstance, "SystemCreationClassName", "CIM_ComputerSystem", CMPI_chars);
                
    systemNamePtr = getSystemName();
    if (systemNamePtr)
    {
        strcpy(systemName, systemNamePtr);
    }
    else
    {
        strcpy(systemName, SYSTEM_NAME);
    }
    CMSetProperty(processorInstance, "SystemName", systemName, CMPI_chars);
    CMSetProperty(processorInstance, "CreationClassName", "INTEL_Processor", CMPI_chars);
    sprintf(deviceID, "%1d", cpu);
    CMSetProperty(processorInstance, "DeviceID", deviceID, CMPI_chars);
                    
    getMSRBitState(cpu, 9, 0x1A0, &prefetchState);
    value = prefetchState;
    CMSetProperty(processorInstance, "HardwarePrefetchState", &value, CMPI_uint16);

    getMSRBitState(cpu, 19, 0x1A0, &prefetchState);
    value = prefetchState;
    CMSetProperty(processorInstance, "AdjacentCacheLinePrefetchState", &value, CMPI_uint16);

    getMSRBitState(cpu, 37, 0x1A0, &prefetchState);
    value = prefetchState;
    CMSetProperty(processorInstance, "DCUPrefetchState", &value, CMPI_uint16);

    printf("READ new CPU\n");
    printf("VALUES\n%d - %d - %d - %s\n", cpuinfo->vendor, cpuinfo->family, cpuinfo->model, cpuinfo->stepping);

    return processorInstance;
}



static int setMSRBitStateForProcessor(uint32_t cpuToSet, uint8_t bit, uint32_t reg, MSRState_t state)
{
    FILE*     cpuinfoFile = NULL;
    cpuinfo_t cpuinfo;
    int       result = 0;
    int       cpu;

    printf("Entered setMSRBitStateForProcessor\n");
    
    if (ALL_PROCESSORS_CORES == cpuToSet)
    {
        cpuinfoFile = fopen(CPU_INFO_FILE, "r");
    
        if (cpuinfoFile)
        {
            int res = 0;
            
            for(cpu = 0; res == 0; cpu++)
            {
                res = readCPUInfo(cpuinfoFile, cpu, &cpuinfo);
                if (res == 0)
                {
                    setMSRBitState(cpu, bit, reg, state);
                }
            }
        }
        else
        {
            printf("Error reading cpu info\n");
            result = -1;
        }
    }
    else
    {
        setMSRBitState(cpuToSet, bit, reg, state);
    }
    
    return result;
}



// ---------------------------------------------------------------

static CMPIStatus INTEL_ProcessorCleanup(CMPIInstanceMI * mi, const CMPIContext * ctx, CMPIBoolean terminate)
{
   CMPIStatus st = { CMPI_RC_OK, NULL };
   
   return (st);
}

static CMPIStatus INTEL_ProcessorGetInstance(CMPIInstanceMI * mi,
                                             const CMPIContext *ctx,
                                             const CMPIResult *rslt,
                                             const CMPIObjectPath *ref,
                                             const char **properties)
{
    FILE*   cpuinfoFile = NULL;
    cpuinfo_t cpuinfo;
    int res = 0;
    CMPIStatus     status = {CMPI_RC_OK, NULL};
    
    CMPIString *className = CMGetClassName(ref, NULL);
    CMPIString *cpuID = NULL;
    CMPIInstance *instProc;
    uint64_t cpu;
    char *resPtr;
    int i;

    printf("Entering INTEL_ProcessorGetInstance\n");

    if (strcasecmp((char*)className->hdl,"intel_processor")==0) 
    {
        cpuID = CMGetKey(ref, "DeviceID", &status).value.string;
        if (cpuID != NULL) 
        {
            printf("CPUID: %s\n", CMGetCharPtr(cpuID));
            cpu = strtoul(CMGetCharPtr(cpuID), &resPtr, 0);
        
            cpuinfoFile = fopen(CPU_INFO_FILE, "r");
    
            if (cpuinfoFile)
            {
                for(i = 0; res == 0 && i <= cpu; i++)
                {
                    res = readCPUInfo(cpuinfoFile, cpu, &cpuinfo);
                    
                    if (res == 0 && i == cpu)
                    {
                        instProc = createInstance(191, &cpuinfo, cpu);
                
                        if (instProc != NULL)
                        {
                            status = CMReturnInstance(rslt, instProc); 
    
                            if (status.rc != CMPI_RC_OK)
                            {
                                printf("Instance Return Error\n");
                                /* RODO: You must release memory */
                            }
                            else
                            {
                                printf("Instance Return OK\n");
                            }
                        }
                    }
                }
            }
            else
            {
                CMSetStatus(&status, CMPI_RC_ERR_FAILED);
            }
        }
        else
        {
            CMSetStatus(&status, CMPI_RC_ERR_INVALID_HANDLE);
        }
    }
    else
    {
        CMSetStatus(&status, CMPI_RC_ERR_INVALID_HANDLE);
    }
    
    CMReturnDone(rslt);
    return status;
}



static CMPIStatus INTEL_ProcessorEnumInstanceNames(CMPIInstanceMI * mi,
                          const CMPIContext * ctx,
                          const CMPIResult * rslt,
                          const CMPIObjectPath * ref)
{
    FILE*   cpuinfoFile = NULL;
    cpuinfo_t cpuinfo;
    int res = 0;
    int cpu;
    CMPIStatus     status = {CMPI_RC_OK, NULL};
    CMPIObjectPath *op = NULL;
    char deviceID[DEVICE_ID_LEN + 1];
    char systemName[SYSTEM_NAME_LEN + 1];
    char *systemNamePtr;

    printf("Entered INTEL_ProcessorEnumInstanceNames\n");

    cpuinfoFile = fopen(CPU_INFO_FILE, "r");
    
    if (cpuinfoFile)
    {
        for(cpu = 0; res == 0; cpu++)
        {
            res = readCPUInfo(cpuinfoFile, cpu, &cpuinfo);
            if (res == 0)
            {
                op = CMNewObjectPath(_broker, CMGetCharPtr(CMGetNameSpace(ref, &status)), "INTEL_Processor", &status);
                if(CMIsNullObject(op)) 
                {
                    CMSetStatusWithChars(_broker, &status, CMPI_RC_ERR_FAILED, "Create CMPIObjectPath failed."); 
                    res = -1;
                }
                else
                {
                    CMAddKey(op, "CreationClassName", "INTEL_Processor", CMPI_chars);
                    CMAddKey(op, "SystemCreationClassName", "CIM_ComputerSystem", CMPI_chars);
                
                    systemNamePtr = getSystemName();
                    if (systemNamePtr)
                    {
                        strcpy(systemName, systemNamePtr);
                    }
                    else
                    {
                        strcpy(systemName, SYSTEM_NAME);
                    }
                    CMAddKey(op, "SystemName", systemName, CMPI_chars);
                    sprintf(deviceID, "%1d", cpu);
                    CMAddKey(op, "DeviceID", deviceID, CMPI_chars);

                    printf("READ new CPU\n");
                    printf("VALUES\n%d - %d - %d - %s\n", cpuinfo.vendor, cpuinfo.family, cpuinfo.model, cpuinfo.stepping);
                    CMReturnObjectPath(rslt, op); /*RODO: Is the memory freed by the MB (instance and objectpath)?*/
                }
            }
        }
    }
    else
    {
        CMSetStatus(&status, CMPI_RC_ERR_FAILED);
    }
    
    CMReturnDone(rslt);
    return status;
}









        

static CMPIStatus INTEL_ProcessorEnumInstances(CMPIInstanceMI       *mi, 
                                               const CMPIContext    *ctx, 
                                               const CMPIResult     *rslt,
                                               const CMPIObjectPath *ref, 
                                               const char **properties)
{
    FILE*   cpuinfoFile = NULL;
    cpuinfo_t cpuinfo;
    int res = 0;
    int cpu;
    CMPIStatus     status = {CMPI_RC_OK, NULL};
    CMPIInstance *instProc;

    printf("Entered INTEL_ProcessorEnumInstances\n");

    cpuinfoFile = fopen(CPU_INFO_FILE, "r");
    
    if (cpuinfoFile)
    {
        for(cpu = 0; res == 0; cpu++)
        {
            res = readCPUInfo(cpuinfoFile, cpu, &cpuinfo);
            if (res == 0)
            {
                instProc = createInstance(191, &cpuinfo, cpu);
                
                if (instProc != NULL)
                {
                    status = CMReturnInstance(rslt, instProc); 
    
                    if (status.rc != CMPI_RC_OK)
                    {
                        printf("Instance Return Error\n");
                        /* RODO: You must release memory */
                    }
                    else
                    {
                        printf("Instance Return OK\n");
                    }
                }
            }
        }
    }
    else
    {
        CMSetStatus(&status, CMPI_RC_ERR_FAILED);
    }
    printf("About to return\n");
    CMReturnDone(rslt);
    return status;
}


static CMPIStatus INTEL_ProcessorCreateInstance(CMPIInstanceMI * mi,
                           const CMPIContext * ctx,
                           const CMPIResult * rslt,
                           const CMPIObjectPath * cop,
                           const CMPIInstance * ci)
{
   return notSuppSt;
}

static CMPIStatus INTEL_ProcessorModifyInstance(CMPIInstanceMI * mi,
                           const CMPIContext * ctx,
                           const CMPIResult * rslt,
                           const CMPIObjectPath * cop,
                           const CMPIInstance * ci, 
                           const char **properties)
{
    CMPIStatus status = {CMPI_RC_OK, NULL};
    CMPIData data;
    uint16_t hardwarePrefetchState;
    uint16_t adjacentCacheLinePrefetchState;
    CMPIString *cpuID = NULL;
    char *resPtr;
    uint32_t cpu;

    printf("Entering INTEL_ProcessorModifyInstance\n");
    
    data = CMGetProperty(ci, "DeviceID", &status);
    if (data.state == CMPI_goodValue)
    {
        cpuID = data.value.string;
        if (cpuID != NULL) 
        {
            printf("CPUID: %s\n", CMGetCharPtr(cpuID));
            cpu = strtoul(CMGetCharPtr(cpuID), &resPtr, 0);
            
            data = CMGetProperty(ci, "HardwarePrefetchState", &status);
    
            if (data.state == CMPI_goodValue)
            {
                hardwarePrefetchState = data.value.uint16;
                printf("HWPref: %d\n", hardwarePrefetchState);
                setMSRBitStateForProcessor(cpu, 9, 0x1A0, (MSRState_t)hardwarePrefetchState);
            }
    
            data = CMGetProperty(ci, "AdjacentCacheLinePrefetchState", &status);
    
            if (data.state == CMPI_goodValue)
            {
                adjacentCacheLinePrefetchState = data.value.uint16;
                printf("AdjCacheLPref: %d\n", adjacentCacheLinePrefetchState);
                setMSRBitStateForProcessor(cpu, 19, 0x1A0, (MSRState_t)adjacentCacheLinePrefetchState);
            }

            data = CMGetProperty(ci, "DCUPrefetchState", &status);
    
            if (data.state == CMPI_goodValue)
            {
                adjacentCacheLinePrefetchState = data.value.uint16;
                printf("DCUPref: %d\n", adjacentCacheLinePrefetchState);
                setMSRBitStateForProcessor(cpu, 37, 0x1A0, (MSRState_t)adjacentCacheLinePrefetchState);
            }
        }
    }
    
    
    return status;
}










static CMPIStatus INTEL_ProcessorDeleteInstance(CMPIInstanceMI * mi,
                           const CMPIContext * ctx,
                           const CMPIResult * rslt,
                           const CMPIObjectPath * ref)
{
    return notSuppSt;
}

static CMPIStatus INTEL_ProcessorExecQuery(CMPIInstanceMI * mi,
                      const CMPIContext * ctx,
                      const CMPIResult * rslt,
                      const CMPIObjectPath * cop,
                      const char *lang, 
                      const char *query)
{
    printf("Entered INTE_ProcessorExecQuery\n");
    return notSuppSt;
}



/*
CMPIStatus INTEL_ProcessorMethodCleanup( CMPIMethodMI * mi, 
           const CMPIContext * ctx, CMPIBoolean terminate) 
{
    CMReturn(CMPI_RC_OK);
}


CMPIStatus INTEL_ProcessorInvokeMethod( CMPIMethodMI * mi,
           const CMPIContext * ctx,
           const CMPIResult * rslt,
           const CMPIObjectPath * ref,
           const char * methodName,
           const CMPIArgs * in,
           CMPIArgs * out) {
  CMPIData         pid;
  CMPIValue        valrc;
  CMPIString     * class = NULL;
  CMPIStatus       rc    = {CMPI_RC_OK, NULL};
  char           * cmd   = NULL;
  char          ** hdout = NULL;
  char          ** hderr = NULL;
  int              cmdrc = 0;

  _OSBASE_TRACE(1,("--- %s CMPI InvokeMethod() called",_ClassName));
  
  class = CMGetClassName(ref, &rc);


  if( strcasecmp(methodName, "setVM") == 0 ) {}



  _OSBASE_TRACE(1,("--- %s CMPI InvokeMethod() exited",_ClassName));
  return rc;
}

*/



CMInstanceMIStub(INTEL_Processor, INTEL_Processor, _broker, CMNoHook);
//CMMethodMIStub(LinuxProcess, LinuxProcess, _broker, CMNoHook);

