#define _GNU_SOURCE

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <linux/major.h>
#include <inttypes.h>

#include "intelmsr.h"
/*
#if defined(i386)
#include <linux/unistd.h>
int _llseek(unsigned int   fd, 
            unsigned long  offset_high, 
            unsigned long  offset_low, 
            loff_t*        result, 
            unsigned int   whence);
_syscall5(int,     _llseek, 
          uint,    fd, 
          ulong,   hi, 
          ulong,   lo, 
          loff_t*, res, 
          uint,    wh);
#endif
*/
#define WORD_EAX  0
#define WORD_EDX  1

static int open_file(unsigned int cpu)
{
	int    msr_fd = -1;
	char   msr_name[20];

	if (msr_fd == -1 && cpu == 0) 
	{
		msr_fd = open("/dev/msr", O_RDWR);
		if (msr_fd == -1 && errno != ENOENT) 
		{
			printf("Cannot open /dev/msr; errno = %d (%s)\n", errno, strerror(errno));
		}
	}

	if (msr_fd == -1) 
	{
		sprintf(msr_name, "/dev/cpu/%u/msr", cpu);
		msr_fd = open(msr_name, O_RDWR);
		if (msr_fd == -1) 
		{
			if (cpu > 0) 
			{
				if (errno == ENXIO)  return -1;
				if (errno == ENODEV) return -1;
			}
			if (errno != ENOENT) 
			{
				printf("Cannot open /dev/msr or %s; errno = %d (%s)\n", 
					msr_name, errno, strerror(errno));
			}
		}
	}

	if (msr_fd == -1) 
	{
		/*
		** Lots of Linux's omit the /dev/msr or /dev/cpu/%u/msr files.  Try
		** creating a temporary file with mknod.
		**
		** mkstemp is of absolutely no security value here because I can't use
		** the actual file it generates, and have to delete it and re-create it
		** with mknod.  But I have to use it anyway to eliminate errors from
		** smartypants gcc/glibc during the link if I attempt to use tempnam.
		*/
		char  tmpname[20];
		strcpy(tmpname, "/tmp/msrXXXXXX");
		int  dummy_fd = mkstemp(tmpname);
		if (dummy_fd != -1) 
		{
			close(dummy_fd);
			remove(tmpname);
			int  status = mknod(tmpname,
                             (S_IFCHR | S_IRUSR),
                             makedev(MSR_MAJOR, cpu));
			if (status == 0) 
			{
				msr_fd = open(tmpname, O_RDONLY);
				remove(tmpname);
			}
		}
		if (msr_fd == -1) 
		{
			if (cpu > 0) 
			{
				if (errno == ENXIO)  return -1;
				if (errno == ENODEV) return -1;
			}
			printf("Cannot open /dev/msr or %s; errno = %d (%s)\n", 
                 msr_name, errno, strerror(errno));
		}
	}

	return msr_fd;
}


static int read_reg (int32_t   msr_fd,
                      uint32_t  reg,
                      uint32_t  words[])
{
	int  status;
/*
#if defined(i386)
	loff_t  result;
	status = _llseek(msr_fd, 0, reg, &result, SEEK_SET);
#else
	status = lseek(msr_fd, reg, SEEK_SET);
#endif*/
	status = lseek(msr_fd, reg, SEEK_SET);
	if (status == -1) 
	{
		printf("Unable to seek msr file to offset 0x%08x;"
			" errno = %d (%s)\n", reg, errno, strerror(errno));
		return -1;
	}

	status = read(msr_fd, words, 8);
	if (status == -1 && errno == EIO) 
	{
		return -1;
	}
	else if (status == -1) 
	{
		printf("Unable to read msr file at offset 0x%08x;"
              " errno = %d (%s)\n", reg, errno, strerror(errno));
        return -1;
	} 
	else 
	{
		return 0;;
	}
}



static int write_reg (int                 msr_fd,
                       unsigned int        reg,
                       const unsigned int  words[])
{
	int  status;
/*
#if defined(i386)
	loff_t  result;
	status = _llseek(msr_fd, 0, reg, &result, SEEK_SET);
#else
	status = lseek(msr_fd, reg, SEEK_SET);
#endif
*/
	status = lseek(msr_fd, reg, SEEK_SET);
	if (status == -1) 
	{
		printf("Unable to seek msr file to offset 0x%08x;"
              " errno = %d (%s)\n", reg, errno, strerror(errno));
		return -1;
	}

	status = write(msr_fd, words, 8);
	if (status == -1 && errno == EIO) 
	{
		return -1;
	} 
	else if (status == -1) 
	{
		printf("Unable to write msr file at offset 0x%08x;"
              " errno = %d (%s)\n", reg, errno, strerror(errno));
		return -1;
	} 
	else 
	{
		return 0;
	}
}




static int modify_reg_field (uint16_t msr_fd,
                  uint32_t reg,
                  uint8_t  field,
                  uint8_t  value)
{
	uint32_t words[2];
	uint32_t auxWord;
	int res;

	res = read_reg(msr_fd, reg, words);

	if (res == -1) 
	{
		printf("ERROR - reading register\n");
		return -1;
	}
	else 
	{
		if (field > 31)
		{
			auxWord = 1;
			field -= 32;
			auxWord = auxWord << field;
			if (value == 1) 
			{
				words[WORD_EDX] |= auxWord;
			}
			else
			{
				auxWord = ~auxWord;
				words[WORD_EDX] &= auxWord;
			}
		}
		else
		{
			auxWord = 1;
			auxWord = auxWord << field;
			if (value == 1) 
			{
				words[WORD_EAX] |= auxWord;
			}
			else
			{
				auxWord = ~auxWord;
				words[WORD_EAX] &= auxWord;
			}
		}
   
		res = write_reg(msr_fd, reg, words);

		if (res == -1) 
		{
			printf("ERROR - writing register\n");
			return -1;
		} 
	}
	
	return 0;
}


static int readMSRField(int      msr_fd,
						uint32_t reg,
						uint8_t  field,
						uint8_t  *value)
{
	uint32_t words[2];
	uint32_t auxWord;
	int res;

	res = read_reg(msr_fd, reg, words);

	if (res == -1) 
	{
		printf("ERROR - reading register\n");
		return -1;
	}
	else 
	{
		if (field > 31)
		{
			field -= 32;
			*value = ((words[WORD_EDX] >> field) & 1);
		}
		else
		{
			*value = ((words[WORD_EAX] >> field) & 1);
		}
	}
	
	return 0;
}



int setMSRBitState(uint32_t cpu, uint8_t bit, uint32_t reg, MSRState_t state)
{
	int msr_fd;
	uint8_t value;
	
	msr_fd = open_file(cpu);
	
	if (msr_fd == -1) return -1;
	
	if (state == MSR_STATE_DISABLED || state == MSR_STATE_ENABLED)
	{
		value = (state == MSR_STATE_ENABLED)?0:1;

	    modify_reg_field(msr_fd, reg, bit, value);
	}
	
	close(msr_fd);
	
	return 0;
}

int getMSRBitState(uint32_t cpu, uint8_t bit, uint32_t reg, MSRState_t *state)
{
	int msr_fd;
	uint8_t value;
	
	msr_fd = open_file(cpu);
	
	if (msr_fd == -1) return -1;
	
    readMSRField(msr_fd, reg, bit, &value);
    
	*state = ((value == 0) ? MSR_STATE_ENABLED : MSR_STATE_DISABLED);
	
	close(msr_fd);
	
	return 0;
}




