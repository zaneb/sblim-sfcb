#include <inttypes.h>


typedef enum
{
	MSR_STATE_UNKNOWN,
	MSR_STATE_OTHER,
	MSR_STATE_ENABLED,
	MSR_STATE_DISABLED
} MSRState_t;

int setMSRBitState(uint32_t cpu, uint8_t bit, uint32_t reg, MSRState_t state);

int getMSRBitState(uint32_t cpu, uint8_t bit, uint32_t reg, MSRState_t *state);




