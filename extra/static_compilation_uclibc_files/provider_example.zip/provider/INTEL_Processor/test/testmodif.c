/*
 * test_si.c
 *
 * (C) Copyright IBM Corp. 2005
 * (C) Copyright Intel Corp. 2005
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * Author:        Adrian Schuur <schuur@de.ibm.com>
 *
 * Description:
 *
 *  Test for setInstance() library API. 
 */

#include <inttypes.h>
#include <cmci.h>
#include <native.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc,char** argv)
{
    CMCIClient *cc;
    CMPIObjectPath * objectpath;
    CMPIInstance * instance;
    CMPIStatus status;
    CMPIValue  prefetch;
    uint32_t cpu;
    uint16_t pref;
    uint16_t field;
    const char *prefProperty;
    char 	*cim_host, *cim_host_passwd, *cim_host_userid;
    
    if (argc < 4) 
    {
    	printf("Bad number of parameters\n");
    	exit(1);
    }
    field = atoi(argv[1]);
    pref = atoi(argv[3]);
    
    cpu = atoi(argv[2]);

    /* Setup a connection to the CIMOM */
    cim_host = getenv("CIM_HOST");
    if (cim_host == NULL)
	cim_host = "10.230.42.96";
    cim_host_userid = getenv("CIM_HOST_USERID");
    if (cim_host_userid == NULL)
	cim_host_userid = "root";
    cim_host_passwd = getenv("CIM_HOST_PASSWD");
    if (cim_host_passwd == NULL)
	cim_host_passwd = "intel123";
    cc = cmciConnect(cim_host, NULL, "5988",
			       cim_host_userid, cim_host_passwd, NULL);
   
    /* Test setInstance() */
    printf("\n----------------------------------------------------------\n");
    printf("Testing setInstance() ...\n");
    objectpath = newCMPIObjectPath("root/cimv2", "INTEL_Processor", NULL);
    CMAddKey(objectpath, "DeviceID", argv[2], CMPI_chars);
    instance = newCMPIInstance(objectpath, NULL);
    prefetch.uint16 = pref;
    
    printf("Prefetcher to be set to %u\n", prefetch.uint16);
    
    
    switch(field)
    {
    	case 9:
    		prefProperty = "HardwarePrefetchState";
    		break;
    	case 19:
    		prefProperty = "AdjacentCacheLinePrefetchState";
    		break;
    	case 37:
    		prefProperty = "DCUPrefetchState";
    		break;
    	default:
    		printf("Bad field passed in argument 1\n");
    		exit(1);
    }

	CMSetProperty(instance, prefProperty, &prefetch, CMPI_uint16);
    status = cc->ft->setInstance(cc, objectpath, instance, 0, NULL);

    /* Print the results */
    printf( "setInstance() rc=%d, msg=%s\n", 
            status.rc, (status.msg)? (char *)status.msg->hdl : NULL);

    if (instance) CMRelease(instance);
    if (objectpath) CMRelease(objectpath);
    if (status.msg) CMRelease(status.msg);
    if (cc) CMRelease(cc);

    return 0;
}

